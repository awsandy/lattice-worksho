#!/bin/bash

source ./env.sh

./deploy-eks.sh
